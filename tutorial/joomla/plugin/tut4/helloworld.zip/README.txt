Tutorial for Joomla templates (Creating a content plugin)
- Refer to http://www.inmotionhosting.com/support/edu/joomla-25/create-plugin/parameter-types
